#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm scryptn2 --pool london.blockbucket.net:3003 --wallet verium-wallet-here
