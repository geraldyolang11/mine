#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-cpu --algorithm argon2d_16000 --pool eu.pool.enaserver.com:4241 --wallet CXhgDPSbPoesuw6gUxKyUrKRPn7CSpyRhD --password c=ADOT --gpu-boost 3
