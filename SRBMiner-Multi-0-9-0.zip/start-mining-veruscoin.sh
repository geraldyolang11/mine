#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm verushash --pool verushash.eu.mine.zergpool.com:3300 --wallet 16GF8LfH1eLW2sWioKvTPoSKZ4U1i8Koci --password c=BTC,mc=VRSC --cpu-threads 2
