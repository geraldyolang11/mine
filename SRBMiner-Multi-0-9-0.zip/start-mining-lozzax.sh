#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm randoml --pool mine.lozzax.xyz:3339 --wallet 45a7c232KKrc43sTZE9wSr3wK1BwBF2CvWuU5LdvTcEFQUmZg1C1N3zdfeGpXu5yVHhsz8xW164ecDw8dMRWsvsFMZwcAtj
